#############################################################################
# Robust variance and gamma swap rates (Fukasawa)
#
# With sigma = sigma_BS(k) * sqrt(t) the total implied volatility and
#   z_-(k) = -k/sigma - sigma/2,   z_+(k) = z_-(k) + sigma,
# the values of the variance and gamma contracts are
#   M = int_0^1 sigma^2 dy,  y = N(z_-(k))   (variance)
#   G = int_0^1 sigma^2 dy,  y = N(z_+(k))   (gamma)
# Between the lowest and highest quoted y, sigma^2 is interpolated in y
# with a Stineman interpolant; beyond them it is extrapolated flat.
# The functions return annualized rates M/t and G/t.
#
# slices:  indices of the expiries to use (default: all)
# exclude: indices of expiries to leave out, e.g. exclude = c(6, 11, 13);
#          indices refer to the sorted expiries in ivolData
#
# Requires library(stinepack).
#############################################################################

# Integral of sigma^2 dy for one slice.
# k: log-strikes log(K/F); sig: total implied vols; type: "var" or "gamma".
fukasawaIntegral <- function(k, sig, type = c("var", "gamma")) {
  type <- match.arg(type)
  z <- -k / sig - sig / 2
  if (type == "gamma") z <- z + sig
  o <- order(z)
  z <- z[o]
  s2 <- sig[o]^2
  keep <- !duplicated(z)           # stinterp needs strictly increasing x
  z <- z[keep]
  s2 <- s2[keep]
  y <- pnorm(z)
  n <- length(y)
  inner <- integrate(function(u) stinterp(x = y, y = s2, xout = u)$y,
                     lower = y[1], upper = y[n])$value
  lower.tail <- s2[1] * y[1]                         # flat on [0, y_min]
  upper.tail <- s2[n] * pnorm(z[n], lower.tail = FALSE)  # flat on [y_max, 1]
  inner + lower.tail + upper.tail
}

# Mid, bid and ask rates for the chosen slices (default: all expiries).
fukasawaRates <- function(ivolData, slices = NULL, exclude = NULL,
                          type = c("var", "gamma")) {
  type <- match.arg(type)
  expDates <- sort(unique(ivolData$Texp))
  if (is.null(slices)) slices <- seq_along(expDates)
  slices <- setdiff(slices, exclude)
  rates <- matrix(NA_real_, nrow = length(slices), ncol = 3,
                  dimnames = list(NULL, c("mid", "bid", "ask")))
  for (i in seq_along(slices)) {
    t <- expDates[slices[i]]
    s <- ivolData[ivolData$Texp == t, ]
    bid <- as.numeric(s$Bid)
    ask <- as.numeric(s$Ask)
    mid <- (bid + ask) / 2
    ok <- !is.na(mid)
    k <- log(s$Strike[ok] / s$Fwd[1])
    vols <- cbind(mid = mid[ok], bid = bid[ok], ask = ask[ok])
    for (j in colnames(rates)) {
      rates[i, j] <- fukasawaIntegral(k, vols[, j] * sqrt(t), type) / t
    }
  }
  list(expiries = expDates[slices], rates = rates)
}

#############################################################################
# Robust variance swap rates
#############################################################################

varSwap.Robust <- function(ivolData, slices = NULL, exclude = NULL) {
  res <- fukasawaRates(ivolData, slices, exclude, type = "var")
  list(expiries = res$expiries,
       vs.mid = res$rates[, "mid"],
       vs.bid = res$rates[, "bid"],
       vs.ask = res$rates[, "ask"])
}

#############################################################################
# Robust gamma swap rates
#############################################################################

gammaSwap.Robust <- function(ivolData, slices = NULL, exclude = NULL) {
  res <- fukasawaRates(ivolData, slices, exclude, type = "gamma")
  list(expiries = res$expiries,
       gs.mid = res$rates[, "mid"],
       gs.bid = res$rates[, "bid"],
       gs.ask = res$rates[, "ask"])
}
