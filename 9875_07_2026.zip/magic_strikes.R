#############################################################################
# Magic-strike approximations to variance and gamma contracts
# (Bourgey and Gatheral, 2026, Propositions 3.2 and 3.3)
#
# Sigma: function returning implied total variance Sigma(k) = sigma_BS(k)^2 T
# Variance contract: stencil centred at k0 = -M/2 with spacing sqrt(M).
# Gamma contract: the variance contract of the reflected smile Sigma(-k).
#############################################################################

magicVar <- function(Sigma, order = 5, tol = 1e-12, maxit = 100) {
  M <- Sigma(0)
  for (it in 1:maxit) {
    k0 <- -M/2; dk <- sqrt(M)
    s <- Sigma(k0 + (-2:2)*dk)                       # Sigma at the five magic strikes
    d0 <- s[3]
    d1 <- (s[4] - s[2])/(2*dk)
    d2 <- (s[4] + s[2] - 2*s[3])/(2*dk^2)
    d3 <- (s[5] - 2*s[4] + 2*s[2] - s[1])/(12*dk^3)
    d4 <- (s[5] - 4*s[4] + 6*s[3] - 4*s[2] + s[1])/(12*dk^2)
    Mn <- d0
    if (order >= 2) Mn <- Mn + M*d2 + d1^2/2
    if (order >= 3) Mn <- Mn - M*d2*d1 - d1^3/4
    if (order >= 4) Mn <- Mn + M*d4 + 5*M*d3*d1 + 2*M*d2^2 + (10 + 3*M)*d2*d1^2/4 + d1^4/8
    if (order >= 5) Mn <- Mn - 5/2*M*d4*d1 - 5*M^2*d3*d2 - 21/2*M*d3*d1^2 -
                         10*M*d2^2*d1 - (9 + M)*d2*d1^3/2 - d1^5/16
    if (abs(Mn - M) < tol) return(Mn)
    M <- Mn
  }
  M
}

magicGamma <- function(Sigma, order = 5, ...) magicVar(function(k) Sigma(-k), order, ...)

# Annualized magic-strike rates for each expiry in an ivolData frame.
# The mid smile is interpolated in k with a Stineman interpolant and
# extrapolated flat; inRange flags slices where all magic strikes are quoted.
magicRates <- function(ivolData, orders = 1:5, slices = NULL, exclude = NULL) {
  expDates <- sort(unique(ivolData$Texp))
  if (is.null(slices)) slices <- seq_along(expDates)
  slices <- setdiff(slices, exclude)
  out <- NULL
  for (i in slices) {
    t <- expDates[i]
    s <- ivolData[ivolData$Texp == t, ]
    mid <- (as.numeric(s$Bid) + as.numeric(s$Ask))/2
    ok <- !is.na(mid)
    k <- log(s$Strike[ok]/s$Fwd[1]); w <- mid[ok]^2*t
    o <- order(k); k <- k[o]; w <- w[o]
    Sigma <- function(x) stinterp(k, w, pmin(pmax(x, k[1]), k[length(k)]))$y
    vs <- sapply(orders, function(n) magicVar(Sigma, n))/t
    gs <- sapply(orders, function(n) magicGamma(Sigma, n))/t
    Mt <- vs[length(vs)]*t; Gt <- gs[length(gs)]*t
    inRange <- (-Mt/2 - 2*sqrt(Mt) >= k[1]) && (Gt/2 + 2*sqrt(Gt) <= k[length(k)])
    out <- rbind(out, c(t, vs, gs, inRange))
  }
  colnames(out) <- c("texp", paste0("vs", orders), paste0("gs", orders), "inRange")
  as.data.frame(out)
}
