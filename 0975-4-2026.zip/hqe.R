###############################################################
#
#  RSQE and HQE simulation of affine forward variance models
#
#      V_t  = xi_0(t) + int_0^t kappa(t-s) sqrt(V_s) dW_s
#      dX_t = -V_t/2 dt + sqrt(V_t) dB_t,      d<W,B>_t = rho dt
#
#  Jim Gatheral, September 2022, 2025; revised September 2026.
#
#  Both schemes follow [Efficient Simulation].  With a step of
#  length dt and kernel integrals
#
#      K0(params)(dt)      = int_0^dt kappa(s) ds
#      Kjj(params)(j, dt)  = int_{j dt}^{(j+1) dt} kappa(s)^2 ds
#
#  (from gamma_kernel.R), the weights  b*_j = sqrt(Kjj(j, dt)/dt)
#  carry the history: the conditional expected variance at the end
#  of step j+1 is
#
#      xihat_{j+1} = xi_0(t_{j+1}) + sum_{i<=j} b*_{j+1-i} chi_i,
#
#  where chi_i is the innovation of step i.  This convolution costs
#  O(j) per step, so the total cost grows like steps^2 per path.
#
#  RSQE: one QE draw per step for V itself; chi is approximated by
#        (V_new - xihat)/b*_0.
#  HQE:  two QE draws per step, one for chi and one for the part of
#        the innovation in V orthogonal to chi.
#
#  Results: x = log S_T, v = V_T, w = int_0^T V dt (one entry per
#  path) and, with path = TRUE, xpath and vpath, the steps x paths
#  arrays of log S and V at every time step.
#
###############################################################

## Andersen's QE rule, for a draw with mean ev and variance psi*ev^2:
##   psiM, for psi <  3/2: squared Gaussian  a (b + w)^2
##   psiP, for psi >= 3/2: atom at zero plus an exponential tail
## (These two are also used by ClassicalHestonMC.AndersenQE in Lecture 4.)
psiM <- function(psi, ev, w) {
    beta2 <- 2/psi - 1 + sqrt(2/psi)*sqrt(abs(2/psi - 1))  # The abs fixes situations where psi > 2
    alpha <- ev/(1 + beta2)
    alpha*(sqrt(abs(beta2)) + w)^2
}

psiP <- function(psi, ev, u) {
    p   <- 2/(1 + psi)
    gam <- ev/2*(1 + psi)
    -(u < p)*gam*log(u/p)
}

## One QE draw for a vector of paths, from one standard normal W per
## path: psiM on the paths with psi < 3/2, psiP on the others, the
## uniform for psiP being pnorm(W).  Each path is evaluated once.
QE.draw <- function(psi, ev, W) {
    quad <- psi < 3/2
    out  <- numeric(length(psi))
    if (any(quad))  out[quad]  <- psiM(psi[quad],  ev[quad],  W[quad])
    if (!all(quad)) out[!quad] <- psiP(psi[!quad], ev[!quad], pnorm(W[!quad]))
    out
}

## Kernel weights b*_j, j = 0, ..., steps-1
bstar.weights <- function(params, dt, steps) sqrt(Kjj(params)(0:(steps - 1), dt)/dt)

## xihat for the next step: forward variance plus the weighted history.
## chi is paths x steps; only its first j columns are filled, and the
## weight vector is zero beyond j, so one product over the whole array
## avoids copying chi[, 1:j] at every step.
next.xihat <- function(xi.next, chi, bstar, bpad, j) {
    bpad[1:j] <- bstar[(j + 1):2]
    xi.next + drop(chi %*% bpad)
}

RSQE.sim <- function(params, xi) function(T, paths, steps, path = FALSE) {

    H      <- params$al - 1/2
    rho    <- params$rho
    rho2m1 <- sqrt(1 - rho^2)
    dt     <- T/steps
    eps.0  <- 1e-10

    bstar  <- bstar.weights(params, dt, steps)
    K00del <- bstar[1]^2*dt                               # int_0^dt kappa^2

    xij   <- xi((1:steps)*dt)
    chi   <- matrix(0, paths, steps)
    bpad  <- numeric(steps)
    v     <- rep(xi(0), paths)
    xihat <- rep(xij[1], paths)
    x     <- numeric(paths)
    w     <- numeric(paths)
    if (path) xpath <- vpath <- matrix(0, steps, paths)

    for (j in 1:steps) {
        xibar <- (xihat + 2*H*v)/(1 + 2*H)                # expected variance averaged over the step
        psi   <- xibar*K00del/xihat^2
        vf    <- QE.draw(psi, xihat, rnorm(paths))        # one QE draw for V
        chi[, j] <- (vf - xihat)/bstar[1]                 # innovation, approximated from V

        dw <- (v + vf)/2*dt                               # integrated variance over the step
        x  <- x - dw/2 + rho2m1*sqrt(dw)*rnorm(paths) + rho*chi[, j]
        w  <- w + dw
        v  <- vf
        if (path) { xpath[j, ] <- x; vpath[j, ] <- v }

        if (j < steps) xihat <- pmax(next.xihat(xij[j + 1], chi, bstar, bpad, j), eps.0)
    }

    res <- list(x = x, v = v, w = w)
    if (path) { res$xpath <- xpath; res$vpath <- vpath }
    res
}

HQE.sim <- function(params, xi) function(T, paths, steps, path = FALSE) {

    H      <- params$al - 1/2
    rho    <- params$rho
    rho2m1 <- sqrt(1 - rho^2)
    dt     <- T/steps
    eps.0  <- 1e-10

    bstar  <- bstar.weights(params, dt, steps)
    K00del <- bstar[1]^2*dt                               # int_0^dt kappa^2
    K0del  <- K0(params)(dt)                              # int_0^dt kappa
    rho.vchi  <- K0del/sqrt(K00del*dt)                    # corr(innovation in V, chi)
    beta.vchi <- K0del/dt                                 # V_new = xihat + beta.vchi*chi + eps
    psi.chi <- 4*K00del*rho.vchi^2                        # psi's below are these times xibar/xihat^2
    psi.eps <- 4*K00del*(1 - rho.vchi^2)

    xij   <- xi((1:steps)*dt)
    chi   <- matrix(0, paths, steps)
    bpad  <- numeric(steps)
    v     <- rep(xi(0), paths)
    xihat <- rep(xij[1], paths)
    x     <- numeric(paths)
    w     <- numeric(paths)
    if (path) xpath <- vpath <- matrix(0, steps, paths)

    for (j in 1:steps) {
        xibar <- (xihat + 2*H*v)/(1 + 2*H)                # expected variance averaged over the step
        m     <- xihat/2
        z.chi <- QE.draw(psi.chi*xibar/xihat^2, m, rnorm(paths))   # two QE draws ...
        z.eps <- QE.draw(psi.eps*xibar/xihat^2, m, rnorm(paths))
        chi[, j] <- (z.chi - m)/beta.vchi                           # ... give chi ...
        vf <- pmax(xihat + beta.vchi*chi[, j] + (z.eps - m), eps.0) # ... and V

        dw <- (v + vf)/2*dt                               # integrated variance over the step
        x  <- x - dw/2 + rho2m1*sqrt(dw)*rnorm(paths) + rho*chi[, j]
        w  <- w + dw
        v  <- vf
        if (path) { xpath[j, ] <- x; vpath[j, ] <- v }

        if (j < steps) xihat <- pmax(next.xihat(xij[j + 1], chi, bstar, bpad, j), eps.0)
    }

    res <- list(x = x, v = v, w = w)
    if (path) { res$xpath <- xpath; res$vpath <- vpath }
    res
}
