# Exact no-butterfly-arbitrage conditions for SVI and SSVI slices.
#
# The idea, following Klassen (2016, revised 2026), is to compactify log-strike.
# For a raw SVI slice, put xi = (k-m)/sqrt((k-m)^2+sig^2), so that xi runs over
# [-1,1] as k runs over the whole real line.  The density factor g is a smooth
# function of xi on the closed interval, including the endpoints xi = +-1
# (k = +-Inf).  Its minimum over [-1,1] is therefore the minimum over ALL k.
#
# For an SSVI slice, g is in addition affine in theta*phi^2, which reduces the
# exact no-arbitrage condition to a one-dimensional minimization (Theorem 4.3 of
# the lecture):
#   theta*phi^2 <= 2 min_{B<0} A(xi)/(-B(xi)) =: theta*phiMax(theta,rho)^2.

########################################################################################
# Density factor g of a raw SVI slice as a function of the compact strike xi
sviGxi <- function(sviparams, xi){
  a <- sviparams$a; b <- sviparams$b; sig <- sviparams$sig
  rho <- sviparams$rho; m <- sviparams$m
  xib <- sqrt(pmax(1 - xi^2, 0))
  D <- a*xib + b*sig*(1 + rho*xi)      # = w * xib (positive iff w > 0)
  kxb <- m*xib + sig*xi                # = k * xib
  wk <- b*(rho + xi)                   # w'(k)
  wkk <- b*xib^3/sig                   # w''(k)
  return((1 - kxb/D*wk/2)^2 - wk^2/4*(xib/D + 1/4) + wkk/2)
}

# Log-strike corresponding to the compact strike xi
sviXiToK <- function(sviparams, xi){
  ifelse(abs(xi) < 1, sviparams$m + sviparams$sig*xi/sqrt(1 - xi^2), sign(xi)*Inf)
}

# Grid on [-1,1] that is dense near the endpoints
xiGrid <- function(n = 2001){sin(pi/2*seq(-1, 1, length.out = n))}

# Minimum of a function f over [-1,1]: grid search refined by optimize()
minOnCompact <- function(f, n = 2001){
  xi <- xiGrid(n)
  fx <- f(xi)
  fx[is.na(fx)] <- Inf
  i <- which.min(fx)
  best <- list(minimum = xi[i], objective = fx[i])
  if (n > 2 && is.finite(fx[i])){
    lo <- xi[max(i - 1, 1)]; hi <- xi[min(i + 1, n)]
    res <- optimize(function(x){y <- f(x); if (is.na(y)) Inf else y},
                    interval = c(lo, hi), tol = 1e-12)
    if (res$objective < best$objective) best <- res
  }
  return(best)
}

# Exact minimum of g over all log-strikes for a single raw SVI slice
sviGmin <- function(sviparams, n = 2001){
  sviparams <- as.list(sviparams)
  minVar <- sviparams$a + sviparams$b*sviparams$sig*sqrt(1 - sviparams$rho^2)
  if (minVar <= 0) return(list(gMin = -Inf, xiMin = NA, kMin = NA))
  res <- minOnCompact(function(xi){sviGxi(sviparams, xi)}, n)
  return(list(gMin = res$objective, xiMin = res$minimum,
              kMin = sviXiToK(sviparams, res$minimum)))
}

# Penalty for butterfly arbitrage on a raw SVI slice:
# negative g anywhere (including k = +-Inf), and the strict call-tail condition
# b(1+rho) < 2 needed for the density to integrate to one.
sviButterflyPenalty <- function(sviparams, n = 401, eps = 1e-4){
  sviparams <- as.list(sviparams)
  minVar <- sviparams$a + sviparams$b*sviparams$sig*sqrt(1 - sviparams$rho^2)
  if (minVar <= 0) return(1 + abs(minVar))
  gMin <- min(sviGxi(sviparams, xiGrid(n)), na.rm = TRUE)
  callTail <- sviparams$b*(1 + sviparams$rho) - (2 - eps)
  return(max(0, -gMin) + max(0, callTail))
}

########################################################################################
# Conversions between raw SVI and SSVI slices

ssviToSvi <- function(theta, rho, phi){
  data.frame(a = theta*(1 - rho^2)/2, b = theta*phi/2, sig = sqrt(1 - rho^2)/phi,
             rho = rho, m = -rho/phi)
}

# Returns theta, rho, phi; rows that are not SSVI slices (to tolerance tol) are NA
sviToSsvi <- function(sviMatrix, tol = 1e-6){
  sviMatrix <- as.data.frame(sviMatrix)
  rho <- sviMatrix$rho
  phi <- sqrt(1 - rho^2)/sviMatrix$sig
  theta <- 2*sviMatrix$b/phi
  err <- pmax(abs(sviMatrix$m + rho/phi)*phi, abs(sviMatrix$a/theta - (1 - rho^2)/2))
  bad <- !(err <= tol)
  if (any(bad)) warning(paste("Slices", paste(which(bad), collapse = ","), "are not SSVI"))
  res <- data.frame(theta = theta, rho = rho, phi = phi)
  res[bad, ] <- NA
  return(res)
}

# SVI-JW slices that are SSVI satisfy c = p + 2 psi and vtilde = v 4pc/(p+c)^2
jwIsSsvi <- function(jw, tol = 1e-6){
  e1 <- abs(jw$ct - jw$pt - 2*jw$psit)/(jw$pt + jw$ct)
  e2 <- abs(jw$varmint/jw$vt - 4*jw$pt*jw$ct/(jw$pt + jw$ct)^2)
  return(e1 <= tol & e2 <= tol)
}

jwToSsvi <- function(jw, texp = jw$texp){
  theta <- jw$vt*texp
  data.frame(theta = theta, rho = (jw$ct - jw$pt)/(jw$ct + jw$pt),
             phi = (jw$pt + jw$ct)/sqrt(theta))
}

########################################################################################
# Klassen's exact bound for an SSVI slice

# Largest phi with non-negative density, for given theta and rho (|rho| < 1).
# Vectorized in theta.
ssviPhiMax <- function(theta, rho, n = 2001){
  rb <- sqrt(1 - rho^2)
  one <- function(th){
    f <- function(xi){
      xb <- sqrt(pmax(1 - xi^2, 0))
      A <- (rb + xb)^2/(4*rb^2)
      B <- xb*(1 - 2*xi^2 - rho*xi + rb*xb)/(4*rb) - th*(rho + xi)^2/32
      ifelse(B < 0, A/(-B), Inf)
    }
    c2star <- minOnCompact(f, n)$objective   # critical radial shape strength
    return(sqrt(2*c2star/th))
  }
  return(sapply(theta, one))
}

# The sufficient bound of Theorem 4.2
ssviPhiMaxGJ <- function(theta, rho){
  x <- 4/(theta*(1 + abs(rho)))
  return(pmin(x, sqrt(x)))
}

ssviSliceArbitrageCheck <- function(theta, rho, phi){
  phiMax <- ssviPhiMax(theta, rho)
  callTail <- theta*phi*(1 + rho) < 4
  data.frame(theta = theta, rho = rho, phi = phi, phiMax = phiMax,
             phiMaxGJ = ssviPhiMaxGJ(theta, rho),
             noArbitrage = (phi <= phiMax) & callTail)
}

jwSsviArbitrageCheck <- function(jw, texp = jw$texp){
  s <- jwToSsvi(jw, texp)
  ssviSliceArbitrageCheck(s$theta, s$rho, s$phi)
}

########################################################################################
# The square-root SSVI surface phi(theta) = eta/sqrt(theta):
# theta*phi^2 = eta^2 on every slice, and phiMax(theta,rho) decreases with theta,
# so there is no butterfly arbitrage exactly for theta <= thetaStar.

ssviSqrtEtaMax <- function(theta, rho){sqrt(theta)*ssviPhiMax(theta, rho)}

ssviSqrtMaxTheta <- function(eta, rho){
  f <- function(lth){ssviSqrtEtaMax(exp(lth), rho) - eta}
  if (f(log(1e-10)) < 0) return(0)
  return(exp(uniroot(f, c(log(1e-10), log(1e4)), tol = 1e-12)$root))
}

ssviSqrtMaxThetaGJ <- function(eta, rho){
  if (eta^2*(1 + abs(rho)) > 4) return(0)
  return(16/(eta^2*(1 + abs(rho))^2))
}

########################################################################################
# Plots

plotSsviPhiBound <- function(rho, eta = NULL, thetaRange = c(1e-3, 10), n = 200){
  theta <- exp(seq(log(thetaRange[1]), log(thetaRange[2]), length.out = n))
  phiMax <- ssviPhiMax(theta, rho)
  phiGJ <- ssviPhiMaxGJ(theta, rho)
  yrange <- range(c(phiMax, phiGJ))
  plot(theta, phiMax, type = "l", log = "xy", lwd = 2, col = "blue", ylim = yrange,
       xlab = expression(theta), ylab = expression(varphi[max](theta)),
       main = bquote(rho == .(round(rho, 3))))
  lines(theta, phiGJ, lwd = 2, lty = 2, col = "red")
  if (!is.null(eta)){
    lines(theta, eta/sqrt(theta), lwd = 2, lty = 3, col = "green4")
    thetaStar <- ssviSqrtMaxTheta(eta, rho)
    if (thetaStar > 0) points(thetaStar, eta/sqrt(thetaStar), pch = 20, cex = 2)
  }
}

plotSsviWingRegion <- function(thetas, xyrange = c(0, 2.1),
                               colors = rainbow(length(thetas)), n = 201){
  rho <- sin(pi/2*seq(-0.999, 0.999, length.out = n))
  plot(NA, xlim = xyrange, ylim = xyrange, asp = 1,
       xlab = "Put wing slope", ylab = "Call wing slope")
  for (j in seq_along(thetas)){
    th <- thetas[j]
    phi <- sapply(rho, function(r){ssviPhiMax(th, r, n = 1001)})
    lines(th*phi*(1 - rho)/2, th*phi*(1 + rho)/2, col = colors[j], lwd = 2)
    phi <- ssviPhiMaxGJ(th, rho)
    lines(th*phi*(1 - rho)/2, th*phi*(1 + rho)/2, col = colors[j], lwd = 2, lty = 2)
  }
  abline(v = 2, h = 2, lty = 3)
  legend("topright", legend = sapply(thetas, function(th){as.expression(bquote(theta == .(th)))}),
         col = colors, lwd = 2, bg = "white")
}
