BSFormula <- function(S0, K, T, r, sigma) {
  x <- log(S0 / K) + r * T
  sig <- sigma * sqrt(T)
  d1 <- x / sig + sig / 2
  d2 <- d1 - sig
  pv <- exp(-r * T)
  return(S0 * pnorm(d1) - pv * K * pnorm(d2))
}

BSFormulaPut <- function(S0, K, T, r, sigma) {
  x <- log(S0 / K) + r * T
  sig <- sigma * sqrt(T)
  d1 <- x / sig + sig / 2
  d2 <- d1 - sig
  pv <- exp(-r * T)
  return(pv * K * pnorm(-d2) - S0 * pnorm(-d1))
}

# Implied volatility of an out-of-the-money option on the forward F, with
# undiscounted price V.  Newton's method in sigma, safeguarded by the bracket
# [1e-10, 10] (bisection whenever a Newton step leaves the bracket).
# Vectorized over all arguments.  Zero prices give 1e-10; NA prices give NA.
BSImpliedVolForwardOTM <- function(F, K, T, V, tol = 1e-12, maxit = 100) {
  n <- max(length(F), length(K), length(T), length(V))
  F <- rep_len(F, n); K <- rep_len(K, n); T <- rep_len(T, n); V <- rep_len(V, n)
  sqrtT <- sqrt(T)
  x <- log(F / K)
  eps <- ifelse(K >= F, 1, -1)                        # calls for K >= F, puts for K < F
  lo <- rep(1e-10, n); hi <- rep(10, n)
  s <- pmin(pmax(sqrt(2 * pi / T) * V / F, 0.05), 2)  # Brenner-Subrahmanyam starting guess
  s[is.na(s)] <- 0.2
  for (it in 1:maxit) {
    sig <- s * sqrtT
    d1 <- x / sig + sig / 2
    f <- eps * (F * pnorm(eps * d1) - K * pnorm(eps * (d1 - sig))) - V
    up <- !is.na(f) & f > 0                             # price too high: sigma too high
    hi[up] <- s[up]; lo[!up] <- s[!up]
    sNew <- s - f / (F * dnorm(d1) * sqrtT)             # Newton step
    bad <- is.na(sNew) | !is.finite(sNew) | sNew < lo | sNew > hi
    sNew[bad] <- (lo[bad] + hi[bad]) / 2                # Bisect instead
    step <- max(abs(sNew - s), na.rm = TRUE)
    s <- sNew
    if (step < tol) break
  }
  s[!is.na(V) & V <= 0] <- 1e-10                        # Zero price: lower bound
  s[is.na(V)] <- NA
  return(s)
}

# This function now works with vectors of strikes and option values
BSImpliedVolCall <- function(S0, K, T, r, C) {
  F <- S0 * exp(r * T)
  c <- C * exp(r * T)                                 # Undiscounted call price
  BSImpliedVolForwardOTM(F, K, T, ifelse(K >= F, c, c - (F - K)))   # Put-call parity for K < F
}

# This function also works with vectors of strikes and option values
BSImpliedVolPut <- function(S0, K, T, r, P) {
  F <- S0 * exp(r * T)
  p <- P * exp(r * T)                                 # Undiscounted put price
  BSImpliedVolForwardOTM(F, K, T, ifelse(K < F, p, p - (K - F)))    # Put-call parity for K >= F
}

BSImpliedVol.OTM <- function(S0, K, T, r, V) {
  F <- S0 * exp(r * T)
  BSImpliedVolForwardOTM(F, K, T, V * exp(r * T))
}

# Function to compute option prices and implied vols given list of
# final values of underlying
bsOut <- function(xf, T, AK) {
  N <- length(xf)
  xfbar <- mean(xf)
  # Sum of call payoffs and of their squares for every strike, from one sort
  s <- sort(xf)
  S1 <- c(rev(cumsum(rev(s))), 0)
  S2 <- c(rev(cumsum(rev(s^2))), 0)
  i <- findInterval(AK, s) + 1
  n <- N - i + 1
  CAV <- (S1[i] - n * AK) / N
  errs <- sqrt(pmax(S2[i] - 2 * AK * S1[i] + n * AK^2 - N * CAV^2, 0) / (N - 1) / N)
  BSV <- BSImpliedVolCall(xfbar, AK, T, 0, CAV)
  BSVL <- BSImpliedVolCall(xfbar, AK, T, 0, CAV - errs)
  BSVH <- BSImpliedVolCall(xfbar, AK, T, 0, CAV + errs)
  err <- errs[length(errs)]                           # As before, err is for the last strike
  return(list(AK = AK, CAV = CAV, BSV = BSV, BSVL = BSVL, BSVH = BSVH, err = err))
}

# Function to return implied vols for a range of strikes
analyticOut <- function(callFormula, AK, T) {
  # callFormula is a function that computes the call price
  callPrice <- sapply(AK, callFormula)
  BSV <- BSImpliedVolCall(1, AK, T, 0, callPrice)
  return(data.frame(AK, callPrice, BSV))
}
