library(stinepack);


plotIvols <- function(ivolData, sviMatrix = NULL, slices = NULL, rowcol = NULL,
                      modelVol = FALSE, plot = TRUE) {

  # Keep rows with a bid vol; log-strikes and mid vols
  ivolData <- ivolData[!is.na(as.numeric(ivolData$Bid)), ]
  bidVols <- as.numeric(ivolData$Bid)
  askVols <- as.numeric(ivolData$Ask)
  midVols <- (bidVols + askVols)/2
  k <- log(ivolData$Strike/ivolData$Fwd)
  texp <- ivolData$Texp
  if (modelVol) modelVols <- as.numeric(ivolData$modelVol)

  expDates <- unique(texp)
  if (is.null(slices)) slices <- seq_along(expDates)
  nSlices <- length(slices)

  # Panel layout: roughly golden-ratio grid unless rowcol is given
  if (plot && nSlices > 1) {
    if (is.null(rowcol)) {
      columns <- max(1, round(sqrt(nSlices*(1 + sqrt(5))/2)))
      rows <- ceiling(nSlices/columns)
    } else {
      rows <- rowcol[1]; columns <- rowcol[2]
    }
    oldPar <- par(mfrow = c(rows, columns), mar = c(3, 3, 2, 0.5), mgp = c(1.7, 0.5, 0),
                  tcl = -0.3, cex.main = 1, cex.lab = 0.9, cex.axis = 0.8)
    on.exit(par(oldPar))
  }

  atmVol <- atmSkew <- atmCurv <- rep(NA_real_, nSlices)

  for (i in seq_len(nSlices)) {
    slice <- slices[i]
    t <- expDates[slice]
    sel <- which(texp == t)
    sel <- sel[order(k[sel])]  # Sort by strike
    k.t <- k[sel]
    bidVols.t <- bidVols[sel]
    askVols.t <- askVols[sel]
    midVols.t <- midVols[sel]

    if (plot) {
      yall <- c(bidVols.t, askVols.t)
      if (modelVol) yall <- c(yall, modelVols[sel])
      yrange <- range(yall, na.rm = TRUE)
      yrange <- yrange + c(-0.1, 0.1)*diff(yrange)
      plot(k.t, bidVols.t, col = "red", pch = 24, cex = 0.5,
           xlim = range(k.t), ylim = yrange,
           main = paste("T =", format(t, digits = 2, nsmall = 2)),
           xlab = "Log-strike", ylab = "Implied vol.")
      points(k.t, askVols.t, col = "blue", pch = 25, cex = 0.5)
      if (modelVol) {
        lines(k.t, modelVols[sel], col = "green4", lwd = 2)
      }
      if (!is.null(sviMatrix)) {
        vol <- function(kk) sqrt(svi(sviMatrix[slice, ], kk)/t)
        curve(vol(x), from = min(k.t), to = max(k.t), col = "orange", lwd = 2, add = TRUE)
      }
    }

    # ATM vol, skew and curvature from a monotone spline through mid vols
    # (duplicate strikes are averaged; NA if k = 0 is not bracketed)
    ku <- unique(k.t)
    if (length(ku) >= 3 && min(ku) < 0 && max(ku) > 0) {
      mu <- as.numeric(tapply(midVols.t, match(k.t, ku), mean))
      volInterp <- function(xout) stinterp(x = ku, y = mu, xout)$y
      atmVol[i] <- volInterp(0)
      h <- atmVol[i]*sqrt(t)/10
      vp <- volInterp(h); vm <- volInterp(-h)
      atmSkew[i] <- (vp - vm)/(2*h)
      atmCurv[i] <- (vp + vm - 2*atmVol[i])/(2*h^2)
    }
  }

  return(list(expiries = expDates[slices], atmVol = atmVol, atmSkew = atmSkew,
              atmCurv = atmCurv))
}

plotTotalVar <- function(ivolData,  slices = NULL,xrange=NULL,yrange=NULL){
  
  bidVols <- as.numeric(ivolData$Bid)
  
  include <- !is.na(bidVols) # Eliminate zero bids
  ivolData <- ivolData[include,]
  
  bidVols <- as.numeric(ivolData$Bid)
  askVols <- as.numeric(ivolData$Ask)
  expDates <- unique(ivolData$Texp)
  
  k <- log(ivolData$Strike/ivolData$Fwd)
  texp <- ivolData$Texp
  
  midVols <- (bidVols + askVols)/2
  
  kmin <- min(k)
  kmax <- max(k)
  
  w <- midVols^2*texp
  
  wmin <- min(w,na.rm=T)
  wmax <- max(w,na.rm=T)
  
  
  nSlices <- length(expDates)
  if (!is.null(slices)) {
    nSlices <- length(slices)
  }
  else {
    slices <- 1:nSlices
  }
  
  plot(k, w, col = "green4", pch = 24, cex = 0.5, xlim=xrange,ylim=yrange,
       xlab = "Log-Strike", ylab = "Total variance",type="n")
  
  for (slice in slices) {
    t <- expDates[slice]
    
    bidVols.t <- bidVols[texp == t]
    askVols.t <- askVols[texp == t]
    midVols.t <- midVols[texp == t]
    k.t <- k[texp == t]
    kmin <- min(k.t)
    kmax <- max(k.t)
    ybottom <- 0.8 * min(bidVols.t,na.rm=T)
    ytop <- 1.2 * max(askVols.t,na.rm=T)
    xrange <- c(kmin, kmax)
    yrange <- c(ybottom, ytop)
    
    w.t <- w[texp==t]
    lines(k.t, w.t, col = "green4")
    
  }
  par(new = F)
  
}

plotSkews <- function(ivolData){
  
  res <- plotIvols(ivolData, sviMatrix = NULL, slices = NULL, modelVol = FALSE, plot=FALSE)
  plot(res$expiries,res$atmSkew,type="b",col="green4",pch=20,xlab="Time to expiry (years)",ylab = "ATM volatility skew")
  
}

plotLogSkews <- function(ivolData){
  
  res <- plotIvols(ivolData, sviMatrix = NULL, slices = NULL, modelVol = FALSE, plot=FALSE)
  plot(log(res$expiries),log(abs(res$atmSkew)),type="b",col="green4",pch=20,
       xlab="Log(time to expiry)",ylab = "log(ATM volatility skew)")
  
}

plotNormalizedSmiles <- function(ivolData, slices = NULL, xrange = NULL, yrange = NULL) {
  # Filter out rows with NA bid volumes
  ivolData <- ivolData[!is.na(ivolData$Bid),]
  
  # Extract necessary data
  bidVols <- as.numeric(ivolData$Bid)
  askVols <- as.numeric(ivolData$Ask)
  expDates <- unique(ivolData$Texp)
  texp <- ivolData$Texp
  k <- log(ivolData$Strike / ivolData$Fwd)
  midVols <- (bidVols + askVols) / 2
  sig_z <- midVols * sqrt(texp)
  z <- k / sig_z
  
  # Determine ranges if not provided
  if (is.null(xrange)) {
    xrange <- range(z, na.rm = TRUE)
  }
  if (is.null(yrange)) {
    yrange <- range(sig_z, na.rm = TRUE)
  }
  
  # Determine slices to plot
  if (is.null(slices)) {
    slices <- seq_along(expDates)
  }
  
  # Plot setup
  plot(z, sig_z, type = "n", col = "brown", pch = 24, cex = 0.5,
       xlim = xrange, ylim = yrange,
       xlab = "Normalized Log-Strike", ylab = "Dimensionless Volatility")
  
  # Plot data for each slice
  for (slice in slices) {
    t <- expDates[slice]
    indices <- texp == t
    
    z_t <- z[indices]
    sig_z_t <- sig_z[indices]
    
    lines(z_t, sig_z_t, col = "brown", lwd = 1.5)
  }
  
  par(new = FALSE)  # Reset graphical parameters
}