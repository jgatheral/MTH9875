source("svi_ssvi_arbitrage.R")

# Function to check sviMatrix for arbitrage
# We do this by checking for real roots, slice by slice pairwise



sviCalendarArbitrageCheck <- function(sviMatrix){

n <- dim(sviMatrix)[1];
arbtot <- 0;

arbcheck <- function(i){ComputeSviRoots(sviMatrix[i:(i+1),])$crossedness}; # Recall that ComputeSviRoots returns discriminants when there is a true real root.
tmp <- sum(sapply(1:(n-1),arbcheck));

return(tmp);
}

# Butterfly arbitrage: the minimum of g over ALL log-strikes is computed exactly
# using sviGmin() from svi_ssvi_arbitrage.R.  The call-tail condition b(1+rho) < 2
# is also checked.

sviSliceArbitrageCheck <- function(sviMatrix){

sviMatrix <- as.data.frame(sviMatrix);
n <- dim(sviMatrix)[1];

arbitrageableSlices <- numeric(0);

for (slice in 1:n){
    sviparams <- as.list(sviMatrix[slice,]);
    gMin <- sviGmin(sviparams)$gMin;
    callTail <- sviparams$b*(1+sviparams$rho) < 2;
    if((gMin < 0) | !callTail) {arbitrageableSlices <- c(arbitrageableSlices,slice)};
}

return(arbitrageableSlices);

}


sviSliceArbitrageCompute <- function(sviMatrix){

sviMatrix <- as.data.frame(sviMatrix);
n <- dim(sviMatrix)[1];

sliceArb <- NULL;

for (slice in 1:n){
    res <- sviGmin(as.list(sviMatrix[slice,]));
    kArb <- res$kMin
    gArb <- min(res$gMin,0)
    sliceArb <- rbind(sliceArb,c(slice,kArb,gArb))
}

sliceArb <- as.data.frame(sliceArb)
names(sliceArb) <- c("slice","kMin","gArb")


return(as.data.frame(sliceArb));

}
