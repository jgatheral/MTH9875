source("svi_ssvi_arbitrage.R")

# Fit the SVI-Sqrt parametrization
# This version gets rid of alpha and fits only slices beyond a certain cutoff expiration.
# Other slices are obtained by projection.
# The fit is constrained to be free of butterfly arbitrage on every slice, using the
# exact (Klassen) condition from svi_ssvi_arbitrage.R:  eta <= sqrt(theta) phiMax(theta,rho)
# for the largest ATM total variance theta.

sviSqrt <- function(sviSqrtParams,k,w0){
rho <- sviSqrtParams$rho;
eta <- sviSqrtParams$eta;
w <- w0/2*(1+rho*eta/sqrt(w0)*k+sqrt((eta/sqrt(w0)*k+rho)^2+1-rho^2));
return(w);
}

sviSqrtParams <- list(rho=-0.7,eta=1);

# Now fit SVI-Sqrt
sviSqrtFit <- function(ivolData){

bidVols <- as.numeric(ivolData$Bid);
askVols <- as.numeric(ivolData$Ask);
texp <- ivolData$Texp;
expDates <- unique(texp);
nSlices <- length(expDates);
nrows <- dim(ivolData)[1];
midV <- numeric(nrows)*NA;
kk <- numeric(nrows)*NA;
ww0 <- numeric(nrows)*NA;
w0 <- numeric(nSlices);

# Compute w0, keeping k and midVar as we go
for (slice in 1:nSlices){
    t <- expDates[slice];
    bidVol <- bidVols[texp==t];
    askVol <- askVols[texp==t];
    pick <- (bidVol>0)&(askVol>0);
    pick <- !is.na(pick)&(bidVol<askVol);
    midVar <- (bidVol[pick]^2+askVol[pick]^2)/2;
    f <- (ivolData$Fwd[texp==t])[1];
    k <- log(ivolData$Strike[texp==t]/f)[pick];
    w0[slice] <- t*stinterp(k,midVar,0)$y;
    # Now put in correct place in columns
    ww0[texp==t][pick]<- w0[slice];
    midV[texp==t][pick]<- midVar;
    kk[texp==t][pick]<- k;
}

tcutoff <- min(0.5,max(expDates));

# Define objective function
obj <- function(sviSqrtParams){
    tmp1 <- as.list(sviSqrtParams);
    names(tmp1) <- c("rho","eta");
    sviSqrtVar <- sviSqrt(tmp1,kk,ww0)/texp;
    tmp <- sum(((midV-sviSqrtVar)^2)[texp >= tcutoff],na.rm=T);
    return(tmp);
};

sviSqrtGuess <- list(rho = - 0.7, eta = 1.0);

fit <- optim(sviSqrtGuess,obj,method="L-BFGS-B",lower=c(-.999,0),upper=c(+.999,+Inf));
res <-as.list(fit$par);

# No butterfly arbitrage on any slice iff eta <= etaMax(rho) (phiMax decreases with theta)
thetaMax <- max(w0);
etaMax <- function(rho){ssviSqrtEtaMax(thetaMax,rho)};
if (res$eta > etaMax(res$rho)){ # The constraint binds: optimize along the boundary
    fit1 <- optimize(function(rho){obj(c(rho,etaMax(rho)))},interval=c(-.999,.999));
    res <- list(rho=fit1$minimum, eta=etaMax(fit1$minimum));
}

# Now convert the result to an SVI matrix
rho <- rep(res$rho,nSlices);
a <- w0/2*(1-rho^2);
gg <- res$eta/sqrt(w0);
b <- w0/2*gg;
m <- -rho/gg;
sig <- sqrt(1-rho^2)/gg;

tmp <- data.frame(a,b,sig,rho,m);

return(tmp);

}
