source("svi_ssvi_arbitrage.R")

# Fit SVI independently to each slice subject to crossing and butterfly penalties.
# The butterfly penalty uses the exact minimum of g over all log-strikes (including
# k = +-Inf), computed in the compact strike coordinate of svi_ssvi_arbitrage.R.

# Two SVI slices as a two-row data.frame, built quickly (rbind is slow inside optim)
sviPair <- function(p1,p2){
p1 <- as.numeric(p1); p2 <- as.numeric(p2);
structure(list(a=c(p1[1],p2[1]),b=c(p1[2],p2[2]),sig=c(p1[3],p2[3]),
               rho=c(p1[4],p2[4]),m=c(p1[5],p2[5])),
          class="data.frame",row.names=1:2)
}

sviFitQR <- function(ivolData,sviGuess,penaltyFactor=1000){

callVals <- as.numeric(ivolData$CallMid);

expDates <- unique(ivolData$Texp);
nSlices <- length(expDates);
slices <- 1:nSlices;
sviMatrix <- sviGuess;
parNames <- c("a","b","sig","rho","m");

######################################
for (slice in slices){  # Start from the earliest slice

t <- expDates[slice];
texp <- ivolData$Texp;

midVal <- callVals[texp==t];

pick <- !is.na(midVal);
midVal <- midVal[pick];
f <- (ivolData$Fwd[texp==t])[1];
k <- log(ivolData$Strike[texp==t]/f)[pick]; # Plot vs log-strike

# Compute squared distance between actual mid-price and theoretical mid-price
sqDist <- function(sviparams){

    tmp1 <- as.list(sviparams);
    names(tmp1) <- parNames # tmp1 is w-style
    sviVar <- svi(tmp1,k)/t; # Convert to variance-style

    outVal <- BSFormula(f, f*exp(k), t, 0, sqrt(abs(sviVar))) # Compute Black-Scholes call values

    tmp <- sum((midVal-outVal)^2,na.rm=T);

    return(tmp);
};

# Normalized squared distance
sqDist0 <- sqDist(sviGuess[slice,]);
sqDistN <- function(sviparams){sqDist(sviparams)/sqDist0}

crossPenalty <- function(sviparams){

    cPenalty <- 0;
    if (slice > 1) { # Compare with previous slice (earlier slice first)
    	cPenalty <- ComputeSviRoots(sviPair(sviMatrix[slice-1,],sviparams))$crossedness}
    if (slice < nSlices) { # Compare with next slice
    	cPenalty <- cPenalty + ComputeSviRoots(sviPair(sviparams,sviMatrix[slice+1,]))$crossedness};

    return(cPenalty);
};

# Butterfly penalty: negative g anywhere, negative variance, or b(1+rho) >= 2
bflyPenalty <- function(sviparams){
    tmp1 <- as.list(sviparams);
    names(tmp1) <- parNames
    return(sviButterflyPenalty(tmp1));
};

# Compute objective function
obj <- function(sviparams){sqDistN(sviparams)+penaltyFactor*(crossPenalty(sviparams)+bflyPenalty(sviparams))};

# Optimize; parscale matters because SVI parameters can be very small for short expirations
guess <- as.numeric(sviGuess[slice,]);
names(guess) <- parNames;
w0 <- svi(as.list(guess),0);
parscale <- c(w0, guess["b"], guess["sig"], 1, guess["sig"]);
fit <- optim(guess,obj,method="L-BFGS-B",
             lower=c(-Inf,0,1e-8,-.999,-Inf),upper=c(Inf,Inf,Inf,.999,Inf),
             control=list(parscale=parscale));
if (fit$value < obj(guess)) sviMatrix[slice,] <- fit$par;

                    }# end of for loop
######################################
sviMatrix <- as.data.frame(sviMatrix);
colnames(sviMatrix) <- parNames;
return(sviMatrix);
}# end of function
