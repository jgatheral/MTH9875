#####################################################################################
# Jim Gatheral, January 2024; implied volatility and Monte Carlo smiles sped up
# October 2026.
#
# Implementations of the Black formula, implied volatility computations, greeks,
# and the Romano-Touzi formula.
#
#####################################################################################

BlackCall <- function (S0, K, T, sigma) 
{
  k <- log(K/S0)
  sig <- sigma * sqrt(T)
  d1 <- -k/sig + sig/2
  d2 <- d1 - sig
  return(S0 * pnorm(d1) - K * pnorm(d2))
}

BlackPut <- function (S0, K, T, sigma) 
{
  k <- log(K/S0)
  sig <- sigma * sqrt(T)
  d1 <- -k/sig + sig/2
  d2 <- d1 - sig
  return( K * pnorm(-d2) - S0 * pnorm(-d1) )
}

BlackOTM <- function (S0, K, T, sigma) 
{
  k <- log(K/S0)
  eps <- ifelse(k>=0,+1,-1)
  sig <- sigma * sqrt(T)
  d1 <- -k/sig + sig/2
  d2 <- d1 - sig
  return(eps*S0*pnorm(eps*d1) - eps*K*pnorm(eps*d2))
}

#####################################################################################
# Implied volatility of an out-of-the-money option (calls for K >= F, puts for K < F)
# with forward F and undiscounted price V, vectorized over all arguments.
#
# Newton's method in sigma, safeguarded by a bracket [1e-10, 10]: whenever a Newton
# step leaves the bracket, we bisect instead.  This converges in a handful of
# iterations to the same answer as bisection.  Zero prices give 1e-10; prices
# above the upper bound give 10; NA prices give NA.
#####################################################################################
ivBlackOTM <- function(F, K, T, V, tol = 1e-12, maxit = 100)
{
  n <- max(length(F), length(K), length(T), length(V))
  F <- rep_len(F, n); K <- rep_len(K, n); T <- rep_len(T, n); V <- rep_len(V, n)
  sqrtT <- sqrt(T)
  k <- log(K/F)
  lo <- rep(1e-10, n); hi <- rep(10, n)
  s <- pmin(pmax(sqrt(2*pi/T)*V/F, 0.05), 2)          # Brenner-Subrahmanyam starting guess
  s[is.na(s)] <- 0.2
  for (it in 1:maxit) {
    f <- BlackOTM(F, K, T, s) - V
    up <- !is.na(f) & f > 0                             # price too high: sigma too high
    hi[up] <- s[up]; lo[!up] <- s[!up]
    sig <- s*sqrtT
    sNew <- s - f/(F*dnorm(-k/sig + sig/2)*sqrtT)       # Newton step
    bad <- is.na(sNew) | !is.finite(sNew) | sNew < lo | sNew > hi
    sNew[bad] <- (lo[bad] + hi[bad])/2                  # Bisect instead
    step <- max(abs(sNew - s), na.rm = TRUE)
    s <- sNew
    if (step < tol) break
  }
  s[!is.na(V) & V <= 0] <- 1e-10                        # Zero price: lower bound
  s[is.na(V)] <- NA
  return(s)
}

# This function works with vectors of strikes and option values
ivCall <- function(S0, K, T, C)
{
  ivBlackOTM(S0, K, T, ifelse(K >= S0, C, C - (S0 - K)))   # Put-call parity for K < S0
}

# This function also works with vectors of strikes and option values  
ivPut <- function (S0, K, T, P) 
{
  ivBlackOTM(S0, K, T, ifelse(K < S0, P, P - (K - S0)))    # Put-call parity for K >= S0
}

ivOTM <- function(S0, K, T, V.OTM){
  ivBlackOTM(S0, K, T, V.OTM)
}

#####################################################################################
# Monte Carlo option prices from a vector of final values Sf of the underlying.
# Sorting Sf once and using cumulative sums gives every strike in one pass:
# for each K, the sum and sum of squares of the payoffs (Sf - K)^+.
#####################################################################################
mcCallMoments <- function(Sf, AK)
{
  N <- length(Sf)
  s <- sort(Sf)
  S1 <- c(rev(cumsum(rev(s))), 0)                    # S1[i] = sum of s[i:N]
  S2 <- c(rev(cumsum(rev(s^2))), 0)
  i <- findInterval(AK, s) + 1                       # first index with s > K
  n <- N - i + 1                                     # number of paths with Sf > K
  sum1 <- S1[i] - n*AK
  sum2 <- S2[i] - 2*AK*S1[i] + n*AK^2
  mean <- sum1/N
  var <- pmax(sum2 - N*mean^2, 0)/(N - 1)
  list(mean = mean, sd = sqrt(var))
}

# Function to compute option prices and implied vols given vector of final values of underlying
ivS <- function (Sf, T, AK) 
{
  Sfbar <- mean(Sf)
  V <- mcCallMoments(Sf, AK)$mean
  V.OTM <- ifelse(Sfbar < AK, V, V + AK - Sfbar)
  return(ivOTM(Sfbar, AK, T, V.OTM))
}

# Function to compute option prices and implied vols given vector of final values of underlying
ivS.list <- function (Sf, T, AK) 
{
  N <- length(Sf)
  Sfbar <- mean(Sf)
  m <- mcCallMoments(Sf, AK)
  stErr <- m$sd/sqrt(N)
  V.OTM <- ifelse(Sfbar < AK, m$mean, m$mean + AK - Sfbar)
  ivBlack <- ivOTM(Sfbar, AK, T, V.OTM)
  ivErr <- ivOTM(Sfbar, AK, T, V.OTM + stErr) - ivOTM(Sfbar, AK, T, V.OTM - stErr)
  res <- list(V.OTM=V.OTM, stErr=stErr, ivBlack=ivBlack,ivErr=ivErr)
  return(res)
}

# Functions to compute Black-Scholes greeks
delta.BS <- function (S0, K, T, sigma) 
{
  k <- log(K/S0)
  eps <- ifelse(k >= 0, +1, -1)
  sig <- sigma * sqrt(T)
  d1 <- -k/sig + sig/2
  d2 <- d1 - sig
  return(pnorm(eps * d1))
}

kappa.BS <- function (S0, K, T, sigma) 
{
  k <- log(K/S0)
  eps <- ifelse(k >= 0, +1, -1)
  sig <- sigma * sqrt(T)
  d1 <- -k/sig + sig/2
  d2 <- d1 - sig
  return(-pnorm(eps * d2))
}

vega.BS <- function (S0, K, T, sigma) 
{
  k <- log(K/S0)
  eps <- ifelse(k >= 0, +1, -1)
  sig <- sigma * sqrt(T)
  d1 <- -k/sig + sig/2
  d2 <- d1 - sig
  return(S0*dnorm(d1)*sqrt(T))
}

# Functions to compute option prices and sensitivities given a vector $Y_T = \int_t^T\,\sqrt{V_s}\,dW_s$
# and a vector $W_T =  \int_t^T\,V_s\,ds$ using the Romano-Touzi formula.

RomanoTouzi.OTM <- function(rho, y, w)Vectorize(function(k){
  
  s0 <- rho*y - rho^2/2*w
  eps <- ifelse(k>=0,+1,-1)
  sig <- sqrt((1-rho^2)*w)
  d1 <- (s0-k)/sig + sig/2
  d2 <- d1 - sig
  res <- eps*exp(s0)*pnorm(eps*d1) - eps*exp(k)*pnorm(eps*d2)
  return(mean(res))  
})

# Sensitivity wrt spot
RomanoTouzi.Delta <- function (rho, y, w) Vectorize(function(k)
{
  s0 <- rho * y - rho^2/2 * w
  eps <- ifelse(k >= 0, +1, -1)
  sig <- sqrt((1 - rho^2) * w)
  d1 <- (s0 - k)/sig + sig/2
  d2 <- d1 - sig
  res <- eps * exp(s0) * pnorm(eps * d1)
  return(mean(res))
})


# Sensitivity wrt strike
RomanoTouzi.Kappa <- function (rho, y, w)Vectorize(function(k) 
{
  s0 <- rho * y - rho^2/2 * w
  eps <- ifelse(k >= 0, +1, -1)
  sig <- sqrt((1 - rho^2) * w)
  d1 <- (s0 - k)/sig + sig/2
  d2 <- d1 - sig
  res <- -eps * pnorm(eps * d2)
  return(mean(res))
})

