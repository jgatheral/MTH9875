###############################################################
#
#  RSQE and HQE simulation of affine forward variance models
#
#      V_t  = xi_0(t) + int_0^t kappa(t-s) sqrt(V_s) dW_s
#      dX_t = -V_t/2 dt + sqrt(V_t) dB_t,      d<W,B>_t = rho dt
#
#  Jim Gatheral, September 2022, 2025; revised September and October 2026.
#
#  Both schemes follow [Efficient Simulation].  With a step of
#  length dt and kernel integrals
#
#      K0(params)(dt)      = int_0^dt kappa(s) ds
#      Kjj(params)(j, dt)  = int_{j dt}^{(j+1) dt} kappa(s)^2 ds
#
#  (from gamma_kernel.R), the weights  b*_j = sqrt(Kjj(j, dt)/dt)
#  carry the history: the conditional expected variance at the end
#  of step j+1 is
#
#      xihat_{j+1} = xi_0(t_{j+1}) + sum_{i<=j} b*_{j+1-i} chi_i,
#
#  where chi_i is the innovation of step i.  Done naively, this
#  convolution costs O(j) per step, so the total cost grows like
#  steps^2 per path.  history() below does it faster:
#    - exponential kernels (classical Heston, H = 1/2): exact O(1)
#      recursion per step;
#    - other kernels: blocked, with each completed block of steps added
#      to all future steps in one matrix-matrix product.
#
#  RSQE: one QE draw per step for V itself; chi is approximated by
#        (V_new - xihat)/b*_0.
#  HQE:  two QE draws per step, one for chi and one for the part of
#        the innovation in V orthogonal to chi.
#
#  Results: x = log S_T, v = V_T, w = int_0^T V dt (one entry per
#  path) and, with path = TRUE, xpath and vpath, the steps x paths
#  arrays of log S and V at every time step.
#
###############################################################

## Andersen's QE rule, for a draw with mean ev and variance psi*ev^2:
##   psiM, for psi <  3/2: squared Gaussian  a (b + w)^2
##   psiP, for psi >= 3/2: atom at zero plus an exponential tail
## (These two are also used by ClassicalHestonMC.AndersenQE in Lecture 4.)
psiM <- function(psi, ev, w) {
    beta2 <- 2/psi - 1 + sqrt(2/psi)*sqrt(abs(2/psi - 1))  # The abs fixes situations where psi > 2
    alpha <- ev/(1 + beta2)
    alpha*(sqrt(abs(beta2)) + w)^2
}

psiP <- function(psi, ev, u) {
    p   <- 2/(1 + psi)
    gam <- ev/2*(1 + psi)
    -(u < p)*gam*log(u/p)
}

## One QE draw for a vector of paths, from one standard normal W per
## path: psiM on the paths with psi < 3/2, psiP on the others, the
## uniform for psiP being pnorm(W).  Each path is evaluated once.
## With zero variance (psi = 0, e.g. eps when H = 1/2 and lambda = 0),
## the draw is just the mean.
QE.draw <- function(psi, ev, W) {
    out  <- ev
    quad <- psi > 1e-12 & psi < 3/2
    expo <- psi >= 3/2
    if (any(quad)) out[quad] <- psiM(psi[quad], ev[quad], W[quad])
    if (any(expo)) out[expo] <- psiP(psi[expo], ev[expo], pnorm(W[expo]))
    out
}

## Kernel weights b*_j, j = 0, ..., steps-1
bstar.weights <- function(params, dt, steps) sqrt(Kjj(params)(0:(steps - 1), dt)/dt)

## The history sum  A_j = sum_{i<=j} b*_{j+1-i} chi_i,  so that
## xihat_{j+1} = xi_0(t_{j+1}) + A_j.  add(j, chi_j) records the
## innovation of step j; sum(j) returns A_j (a vector over paths).
history <- function(bstar, paths, steps, block = 64) {

    b0 <- bstar[1]
    r  <- if (steps > 1) bstar[-1]/bstar[-steps] else 1
    if (all(abs(r - r[1]) <= 1e-8*abs(r[1]))) {
        ## Exponential kernel: b*_k = b*_0 r^k, so A_j = r (A_{j-1} + b*_0 chi_j)
        r <- r[1]
        A <- numeric(paths)
        return(list(add = function(j, chi.j) A <<- r*(A + b0*chi.j),
                    sum = function(j) A))
    }

    ## General kernel.  F[, m] holds the contributions to A_{m-1} of all
    ## completed blocks; the current block is summed directly.
    chi <- matrix(0, paths, steps)
    F   <- matrix(0, paths, steps)
    s0  <- 1                                              # first step of the current block
    add <- function(j, chi.j) {
        chi[, j] <<- chi.j
        if (j - s0 + 1 == block && j < steps) {           # block complete: push it forward
            blk <- s0:j; tgt <- (j + 1):steps
            Tm  <- matrix(bstar[outer(blk, tgt, function(i, m) m - i + 1)], length(blk))
            F[, tgt] <<- F[, tgt] + chi[, blk, drop = FALSE] %*% Tm
            s0 <<- j + 1
        }
    }
    sum <- function(j) {
        near <- if (j >= s0) drop(chi[, s0:j, drop = FALSE] %*% bstar[(j + 2 - s0):2]) else 0
        F[, j + 1] + near
    }
    list(add = add, sum = sum)
}

RSQE.sim <- function(params, xi) function(T, paths, steps, path = FALSE) {

    H      <- params$al - 1/2
    rho    <- params$rho
    rho2m1 <- sqrt(1 - rho^2)
    dt     <- T/steps
    eps.0  <- 1e-10

    bstar  <- bstar.weights(params, dt, steps)
    K00del <- bstar[1]^2*dt                               # int_0^dt kappa^2

    xij   <- xi((1:steps)*dt)
    hist  <- history(bstar, paths, steps)
    v     <- rep(xi(0), paths)
    xihat <- rep(xij[1], paths)
    x     <- numeric(paths)
    w     <- numeric(paths)
    if (path) xpath <- vpath <- matrix(0, steps, paths)

    for (j in 1:steps) {
        xibar <- (xihat + 2*H*v)/(1 + 2*H)                # expected variance averaged over the step
        psi   <- xibar*K00del/xihat^2
        vf    <- QE.draw(psi, xihat, rnorm(paths))        # one QE draw for V
        chi   <- (vf - xihat)/bstar[1]                    # innovation, approximated from V
        hist$add(j, chi)

        dw <- (v + vf)/2*dt                               # integrated variance over the step
        x  <- x - dw/2 + rho2m1*sqrt(dw)*rnorm(paths) + rho*chi
        w  <- w + dw
        v  <- vf
        if (path) { xpath[j, ] <- x; vpath[j, ] <- v }

        if (j < steps) xihat <- pmax(xij[j + 1] + hist$sum(j), eps.0)
    }

    res <- list(x = x, v = v, w = w)
    if (path) { res$xpath <- xpath; res$vpath <- vpath }
    res
}

HQE.sim <- function(params, xi) function(T, paths, steps, path = FALSE) {

    H      <- params$al - 1/2
    rho    <- params$rho
    rho2m1 <- sqrt(1 - rho^2)
    dt     <- T/steps
    eps.0  <- 1e-10

    bstar  <- bstar.weights(params, dt, steps)
    K00del <- bstar[1]^2*dt                               # int_0^dt kappa^2
    K0del  <- K0(params)(dt)                              # int_0^dt kappa
    rho.vchi  <- K0del/sqrt(K00del*dt)                    # corr(innovation in V, chi)
    beta.vchi <- K0del/dt                                 # V_new = xihat + beta.vchi*chi + eps
    psi.chi <- 4*K00del*rho.vchi^2                        # psi's below are these times xibar/xihat^2
    psi.eps <- 4*K00del*(1 - rho.vchi^2)

    xij   <- xi((1:steps)*dt)
    hist  <- history(bstar, paths, steps)
    v     <- rep(xi(0), paths)
    xihat <- rep(xij[1], paths)
    x     <- numeric(paths)
    w     <- numeric(paths)
    if (path) xpath <- vpath <- matrix(0, steps, paths)

    for (j in 1:steps) {
        xibar <- (xihat + 2*H*v)/(1 + 2*H)                # expected variance averaged over the step
        m     <- xihat/2
        q     <- xibar/xihat^2
        z.chi <- QE.draw(psi.chi*q, m, rnorm(paths))      # two QE draws ...
        z.eps <- QE.draw(psi.eps*q, m, rnorm(paths))
        chi   <- (z.chi - m)/beta.vchi                    # ... give chi ...
        vf    <- pmax(xihat + beta.vchi*chi + (z.eps - m), eps.0)   # ... and V
        hist$add(j, chi)

        dw <- (v + vf)/2*dt                               # integrated variance over the step
        x  <- x - dw/2 + rho2m1*sqrt(dw)*rnorm(paths) + rho*chi
        w  <- w + dw
        v  <- vf
        if (path) { xpath[j, ] <- x; vpath[j, ] <- v }

        if (j < steps) xihat <- pmax(xij[j + 1] + hist$sum(j), eps.0)
    }

    res <- list(x = x, v = v, w = w)
    if (path) { res$xpath <- xpath; res$vpath <- vpath }
    res
}
