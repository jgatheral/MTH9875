###############################################################
#
# Generates spx_heston_20230215.rData for Lecture 8:
#   - classical Heston fit to SPX implied vols on 15-Feb-2023,
#     with the forward variance curve adjusted to match ATM vols
#   - empirical and Heston ATM skews for all expirations
#
# Needs: spx_vix_vols_20230215.rData, xi_20230215.rData, fwd_var_curve.R
#
###############################################################

library(stinepack)
source("fwd_var_curve.R")
load("spx_vix_vols_20230215.rData")
load("xi_20230215.rData")

#--------------------------------------------------------------
# Heston characteristic function with a general forward variance curve xi:
# log phi_T(a) = int_0^T xi(T-s) g(a,s) ds, where h solves the Riccati equation
# h' = -a(a+i)/2 + (i rho nu a - lam) h + nu^2 h^2/2, h(0) = 0
#--------------------------------------------------------------
hHeston <- function(params, a, s){
  nu <- params$nu; lam <- params$lam; rho <- params$rho
  lt <- lam/nu - 1i*rho*a; A <- sqrt(a*(a + 1i) + lt^2); rm <- lt - A; rp <- lt + A
  e <- exp(-nu*A*s)
  rm*(1 - e)/(1 - (rm/rp)*e)/nu
}

logPhiHeston <- function(params, xi, a, T, n = 40){
  nu <- params$nu; lam <- params$lam; rho <- params$rho
  lt <- lam/nu - 1i*rho*a; aa <- sqrt(a*(a + 1i) + lt^2); rm <- lt - aa; rp <- lt + aa
  # Simpson in y with s = T y^2 (graded towards s = 0)
  y <- (0:n)/n; s <- T*y^2; w <- rep(c(2, 4), length.out = n + 1); w[1] <- 1; w[n + 1] <- 1
  wy <- w*2*T*y/(3*n); xis <- xi(T - s)
  acc <- 0
  for (j in 2:(n + 1)){
    h <- hHeston(params, a, s[j]); g <- 0.5*(nu*h - rm)*(nu*h - rp) + lam*h
    acc <- acc + wy[j]*xis[j]*g
  }
  acc
}

# OTM option prices (forward = 1) by Lewis-style Fourier inversion
otmHeston <- function(params, xi, k, T){
  sig <- sqrt(xi(T/2)); umax <- 10/(sig*sqrt(T))
  repeat{
    if (Mod(exp(logPhiHeston(params, xi, umax - 0.5i, T, 200))) < 1e-8 || umax > 20000) break
    umax <- 2*umax
  }
  n <- 2*ceiling(max(20 + 20*T, umax/25))
  u1 <- seq(0.01, 10, by = 0.02); d1 <- rep(0.02, length(u1))
  du2 <- min(0.3, max(0.1, (umax - 10)/1500)); u2 <- seq(10 + du2/2, umax, by = du2); d2 <- rep(du2, length(u2))
  u <- c(u1, u2); du <- c(d1, d2)
  ph <- exp(logPhiHeston(params, xi, u - 0.5i, T, n))
  integ <- as.numeric(Re(exp(-1i*outer(k, u)) %*% (du*ph/(u^2 + 0.25))))
  exp(pmin(k, 0)) - exp(k/2)/pi*integ
}

# Black-Scholes implied vols of OTM options by bisection
impvolOTM <- function(k, T, p){
  bs <- function(s){ sq <- s*sqrt(T); d1 <- -k/sq + sq/2; d2 <- d1 - sq
    ifelse(k >= 0, pnorm(d1) - exp(k)*pnorm(d2), exp(k)*pnorm(-d2) - pnorm(-d1)) }
  lo <- rep(1e-4, length(k)); hi <- rep(3, length(k))
  for (i in 1:60){ mid <- (lo + hi)/2; up <- bs(mid) > p; hi[up] <- mid[up]; lo[!up] <- mid[!up] }
  v <- (lo + hi)/2; v[p <= 0 | is.na(p)] <- NA; v
}

impvolHeston <- function(params, xi, k, T) impvolOTM(k, T, otmHeston(params, xi, k, T))

#--------------------------------------------------------------
# Data: 16 expirations from one week to two years, up to 25 strikes each
#--------------------------------------------------------------
d <- spxIvols20230215
d <- d[!is.na(d$Bid) & !is.na(d$Ask), ]
d$k <- log(d$Strike/d$Fwd); d$mid <- (d$Bid + d$Ask)/2; d$spr <- pmax(d$Ask - d$Bid, 0.002)
Tsel <- c(0.0192, 0.0383, 0.0575, 0.0767, 0.1013, 0.1588, 0.1971, 0.2546, 0.3313, 0.4271,
          0.5038, 0.5804, 0.7529, 1.0021, 1.347, 1.8453)
texps <- sort(unique(d$Texp)); Tuse <- sapply(Tsel, function(t) texps[which.min(abs(texps - t))])
volData <- do.call(rbind, lapply(Tuse, function(T){
  s <- d[d$Texp == T, ]; atm <- s$mid[which.min(abs(s$k))]; sd <- atm*sqrt(T)
  s <- s[s$k > -6*sd & s$k < 3*sd, ]
  if (nrow(s) > 25) s <- s[round(seq(1, nrow(s), length = 25)), ]
  s }))
atmData <- sapply(Tuse, function(T){
  s <- d[d$Texp == T, ]; atm <- s$mid[which.min(abs(s$k))]; sd <- atm*sqrt(T)
  near <- s[abs(s$k) < 1.5*sd, ]; unname(coef(lm(mid ~ k + I(k^2), data = near))[1]) })

#--------------------------------------------------------------
# Forward variance curve, adjusted so that model ATM vols match the market
#--------------------------------------------------------------
e0 <- xiCurveObj$thisEnv
Tk <- get("expiries", e0); w <- get("w.in", e0); epsCurve <- get("eps", e0)
buildXi <- function(w){ o <- CurveSmoothBuilder(Tk, w, eps = epsCurve); o$fitCurve(); o$getForwardVarCurve() }
xi <- buildXi(w)

adjustXi <- function(p, iters = 10, damp = 0.5, tol = 5e-4){
  for (i in 1:iters){
    am <- sapply(Tuse, function(T) impvolHeston(p, xi, 0, T))
    err <- max(abs(am - atmData))
    cat(sprintf("ATM iteration %d: max |ATM error| = %.4f\n", i, err))
    if (err < tol) break
    f <- approx(log(Tuse), log((atmData/am)^2), xout = log(Tk), rule = 2)$y
    w <<- w*exp(damp*f); xi <<- buildXi(w)
  }
}

#--------------------------------------------------------------
# Fit (nu, rho, lambda), alternating with the ATM adjustment.  This takes a while;
# set doFit <- FALSE to use the parameters from Lecture 8.
#--------------------------------------------------------------
doFit <- FALSE
p <- list(nu = 1.253017, rho = -0.6397645, lam = 2.371669)

if (doFit){
  model <- function(p) unlist(lapply(Tuse, function(T){ s <- volData[volData$Texp == T, ]; impvolHeston(p, xi, s$k, T) }))
  toP <- function(x) list(nu = exp(x[1]), rho = -0.99/(1 + exp(-x[2])), lam = exp(x[3]))
  fromP <- function(p) c(log(p$nu), log(-p$rho/(0.99 + p$rho)), log(p$lam))
  obj <- function(x){ m <- model(toP(x)); sum(((m - volData$mid)/volData$spr)^2, na.rm = TRUE) + 1e4*sum(is.na(m)) }
  p <- list(nu = 1.18, rho = -0.636, lam = 1.99)  # Initial guess
  for (round in 1:2){
    adjustXi(p)
    res <- optim(fromP(p), obj, method = "Nelder-Mead", control = list(maxit = 120, reltol = 1e-6))
    p <- toP(res$par); print(unlist(p))
  }
}
adjustXi(p)

#--------------------------------------------------------------
# Model vols, and empirical vs Heston ATM skews for all expirations
#--------------------------------------------------------------
volData$modelVol <- unlist(lapply(Tuse, function(T){ s <- volData[volData$Texp == T, ]; impvolHeston(p, xi, s$k, T) }))
volData <- volData[, c("Expiry", "Texp", "Strike", "Bid", "Ask", "Fwd", "modelVol")]

skewData <- do.call(rbind, lapply(texps[texps > 0.004], function(T){
  s <- d[d$Texp == T, ]; atm <- s$mid[which.min(abs(s$k))]; sd <- atm*sqrt(T)
  near <- s[abs(s$k) < sd, ]
  if (nrow(near) < 6) return(NULL)
  cf <- coef(lm(mid ~ k + I(k^2), data = near))
  h <- 0.02*sqrt(T); v <- impvolHeston(p, xi, c(-h, h), T)
  data.frame(T = T, atmVol = unname(cf[1]), skew = -unname(cf[2]), hestonSkew = (v[1] - v[2])/(2*h))
}))

spxHeston20230215 <- list(volData = volData, skewData = skewData,
                          params = list(nu = p$nu, rho = p$rho, lambda = p$lam))
save(spxHeston20230215, file = "spx_heston_20230215.rData")
